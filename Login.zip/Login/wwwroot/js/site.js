﻿
$(document).ready(function() {

    $("#login_btn").click(function(){
       $("#page").effect( "shake", {times:4}, 1000 );
    });
        
 });
